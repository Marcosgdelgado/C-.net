﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*Dado el arreglo {10,20,5,15,30,20} X
Informar el arreglo de la forma: "Indice: X, Valor: Y" X
Totalizar el arreglo e informar el total X
Informar el contenido de las posiciones impares (por ejemplo, las posiciones 1,3,5,etc) X
Informar el mayor número X
Informar cuántas veces aparece el número 20 X*/
namespace Programacion1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arreglo = new int[6] { 10, 20, 5, 15, 30, 20 };
            int total=0;
            int mayor= arreglo[0]; //inicializar mayores y menores con primer indice del array 
            int contador = 0;
            
            for (int i = 0; i < arreglo.Length; i++)
            {
                Console.WriteLine("La posicion es: {0}, su valor es: {1}", i, arreglo[i]);

                total = arreglo[i] + total;
                if (arreglo[i]>mayor)
                {
                    mayor = arreglo[i];
                }
                if (arreglo[i]==20)
                {
                    contador++;
                }
            }
            Console.WriteLine();
            for (int i = 0; i < arreglo.Length; i++)
            {
                if (arreglo[i] % 2 != 0)
                {
                    Console.WriteLine("Los numeros impares, posicion: {0}, valor: {1}", i, arreglo[i]);
                }
            }

            Console.WriteLine("\n20 aparece: {0}", contador);
            Console.WriteLine("\nEl mayor es: {0}", mayor);
            Console.WriteLine("\nEl total es: {0}", total);
            Console.ReadKey();
        }
    }
}
