﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Copiar el contenido del arreglo origen al arreglo destino, 
 * dejando en este último los valores invertidos respecto del arreglo origen. Utilizar
    estructura de control de flujo repetitiva, y luego informar el índice y los valores del nuevo arreglo.Arreglo origen
0 1002
1 104
2 309
3 500
Arreglo destino
0 500
1 309
2 104
3 1002
 */
namespace Ejercicio6
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] origen = new int[4] {1002,104,309,500};
            int[] destino = new int[origen.Length];
            //Random rand = new Random(); //generador de numeros aleatorios
            int size = rand.next(10, 100);
            //int[] miArr = new int[size]; Creador arrays dinamicos.
            
            /*for (int i = 0; i < origen.Length; i++)
            {
                origen[i] = rand.Next(1,100);
            }*/ //Carga de numeros random a array

            for (int i = 0,j = destino.Length -1; i < origen.Length; i++, j--)
            {
                    destino[j] = origen[i];
                // destino[j] = origen[i]; mismo resultado, recorrido inverso

            }
            for (int i = 0; i < destino.Length; i++)
            {
                Console.WriteLine("Posicion: {0}, valor: {1}", i, destino[i]);
            }
            
            Console.ReadKey();
        }
    }
}
