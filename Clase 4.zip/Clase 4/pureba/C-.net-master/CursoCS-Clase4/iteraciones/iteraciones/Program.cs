﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace iteraciones
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero = 1;

            while(numero < 11)
            {
                if(numero != 2 && numero != 5 && numero != 9)
                {
                    Console.WriteLine(numero);
                }
                numero++;
            }
            Console.WriteLine("-----------------");

            int suma = 0;
            numero = 1;
            while (numero < 11)
            {
                suma += numero;
                Console.WriteLine(suma);
                numero++;
            }
            Console.WriteLine("TOTAL {0}",suma);

            Console.WriteLine("---------------");
            for(int i=0; i<5; i++)
            {
                //if (i % 2 == 0)
                /*
                if ((i & 1) == 0)
                    Console.WriteLine("@");
                else
                    Console.WriteLine("@@");
                */
                if(i % 2 != 0) Console.Write("+");
                Console.WriteLine("@");
            }






            Console.ReadKey();
        }
    }
}
