﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numeros = new int[10] { 5,7,24,66,93,-140,2,43,28,94 };
            //numeros = new int[10];
            for (int i = 0; i < numeros.Length; i++)
            {
                //numeros[i] = i + 55;
            }


            for (int i=0; i<numeros.Length; i++)
            {
                Console.WriteLine("indice: {0} - contenido: {1}",i,numeros[i]);
            }

            Console.WriteLine("\n--------------------------------");
            double suma = 0;
            for (int i = 0; i < numeros.Length; i++)
            {
                suma += numeros[i];
                Console.WriteLine("index: {0} - contenido: {1} - suma: {2}", i, numeros[i], suma);
            }
            Console.WriteLine("suma TOTAL: {0}", suma);
            Console.WriteLine("Promedio: {0}", suma / numeros.Length);

            Console.WriteLine("\n--------------------------------");
            int minimo = numeros[0];
            int maximo = numeros[0];
            int posMinimo = 0;
            int posMaximo = 0;
            for (int i = 0; i < numeros.Length; i++)
            {
                if (numeros[i] > maximo)
                {
                    maximo = numeros[i];
                    posMaximo = i;
                }
                if (numeros[i] < minimo)
                {
                    minimo = numeros[i];
                    posMinimo = i;
                }
            }
            Console.WriteLine("minimo: {0} - maximo: {1}", minimo, maximo);
            Console.WriteLine("posMinimo: {0} - posMaximo: {1}", posMinimo, posMaximo);

            Console.WriteLine("\n------------- ORDENAMIENTO -------------------");
            for(int i=1; i<numeros.Length; i++)
            {
                for(int j=0; j < numeros.Length-1; j++ )
                {
                    //if (numeros[j] < numeros[j + 1]) //orden descendente
                    if (numeros[j] > numeros[j + 1]) //orden ascendente
                    {
                        int valor = numeros[j];
                        numeros[j] = numeros[j + 1];
                        numeros[j + 1] = valor;
                    }
                }
            }
            for (int i = 0; i < numeros.Length; i++)
            {
                Console.WriteLine("indice: {0} - contenido: {1}", i, numeros[i]);
            }

            int[] facturacionPorMes = new int[6];

            string[] nombreMeses = new string[] { "enero", "febrero", "marzo", "abril", "mayo", "junio" };
            for (int mes=1; mes<=6; mes++)
            {
                Console.WriteLine("Ingrese facturación de {0}", nombreMeses[mes - 1]);
                int facturacion = Int32.Parse(Console.ReadLine());
                facturacionPorMes[mes-1] = facturacion;
            }


            suma = 0;
            minimo = facturacionPorMes[0];
            maximo = facturacionPorMes[0];
            posMinimo = 0;
            posMaximo = 0;
            for (int i = 0; i < facturacionPorMes.Length; i++)
            {
                suma += facturacionPorMes[i];
                Console.WriteLine("index: {0} - contenido: {1} - suma: {2}", i, facturacionPorMes[i], suma);
                if (facturacionPorMes[i] > maximo)
                {
                    maximo = facturacionPorMes[i];
                    posMaximo = i;
                }
                if (facturacionPorMes[i] < minimo)
                {
                    minimo = facturacionPorMes[i];
                    posMinimo = i;
                }
            }
            Console.WriteLine("facturacionPorMes");
            Console.WriteLine("\tsuma TOTAL: {0}", suma);
            Console.WriteLine("\tPromedio: {0}", suma / facturacionPorMes.Length);
            Console.WriteLine("\tminimo: {0} - maximo: {1}", minimo, maximo);
            Console.WriteLine("\tposMinimo: {0} - posMaximo: {1}", posMinimo, posMaximo);

            int[] array1 = new int[] { 1, 2, 3, 4, 5, 6 };
            int[] array2 = new int[array1.Length];

            for(int i=0; i<array1.Length; i++)
            {
                array2[array1.Length-1-i] = array1[i];
            }
            for (int i = 0; i < array1.Length; i++)
            {
                Console.WriteLine("indice: {0} - contenido: {1}", i, array1[i]);
            }
            for (int i = 0; i < array2.Length; i++)
            {
                Console.WriteLine("indice: {0} - contenido: {1}", i, array2[i]);
            }

            Console.ReadKey();

        }
    }
}
