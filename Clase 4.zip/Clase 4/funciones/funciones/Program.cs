﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace funciones
{
    class Program
    {
        static int ObtenerRandom(Random rand, int valorMinimo, int valorMaximo)
        {
           
            int random = rand.Next(valorMinimo,valorMaximo);

            return random;
        }

        static void Main(string[] args)
        {
           
            Random rand = new Random();
            int[] numero = new int[ObtenerRandom(rand, 1, 100)];
            int suma = 0;
            for (int i = 0; i <numero.Length; i++)
            {
                numero[i] = ObtenerRandom(rand,1, 100);
                Console.WriteLine("Numero es: {0}", numero[i]);
                //Console.WriteLine(ObtenerRandom(rand,1,100));
                suma++;
            }

            Operaciones operaciones = new Operaciones();
            
            Console.WriteLine("\nSuma con clases: {0}", operaciones.Sumar(8, 9));
            Console.WriteLine("Resta con clases: {0}", operaciones.Restar(8, 9));
            Console.WriteLine("DIV con clases: {0}", operaciones.Dividir(8, 2));
            Console.WriteLine("mult con clases: {0}", operaciones.Sumar(8,10));


            Console.WriteLine("\nLa suma total es: {0}",suma);
            Console.ReadKey();
        }
    }
}
