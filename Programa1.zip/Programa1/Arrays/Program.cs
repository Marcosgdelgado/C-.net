﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            //Codificado de array Int[] numeros = new int[10];
            //Int[] numeros = new int[10]{1,2,3,4....10}; si o si cargados la cantidad de dimension array osea 10 de 10
            // se puede hardcodear
            // si dejo vacios[] y cargo {1,2,3....} el array se autodimensiona
            //numeros.length devuelve cantidad cargados
            // Int[] numeros = new int[2,10]; array de dos elementos, array multidimensional
            //Int[] numeros = new int[4,2,10]; array tridimensional
            int[] numeros = new int[10] {5,7,-6,9,10,11,2,3,22,15};
            double suma = 0;
            int minimo = numeros[0];
            int maximo = numeros[0];
            int postMinimo = 0;
            int postMaximo = 0;

            for (int i = 0; i < numeros.Length; i++)
            {
                Console.WriteLine("Indice {0} - contenido: {1}",i,numeros[i]);
            }
            Console.WriteLine();
           
            for (int i = 0; i < numeros.Length; i++)
            {
                suma += numeros[i];
                Console.WriteLine("Indice: {0}\tContenido: {1}\tSuma: {2} ", i, numeros[i],suma);
            }
            Console.WriteLine("Suma TOTAL: {0}", suma);
            Console.WriteLine("Promedio: {0}", suma / numeros.Length);

            Console.WriteLine();
            
            for (int i = 0; i < numeros.Length; i++)
            {
                if (numeros[i] > maximo)
                {
                    maximo = numeros[i];
                    postMaximo = i;
                }
                if (numeros[i] < minimo)
                {
                    minimo = numeros[i];
                    postMinimo = i;
                }
            }
            Console.WriteLine("Minimo: {0}\tPosicion Minimo: {2}\nMaximo: {1}\tPosicion Maximo: {3}", minimo, maximo,postMinimo,postMaximo);

            Console.WriteLine("\nBURBUGEO (ASCENDENTE)\n");

            for (int i = 1; i < numeros.Length; i++)
            {
                for (int j = 0; j < numeros.Length -1; j++)
                {
                    if (numeros[j]<numeros[j+1])
                    {
                        int valor = numeros[j];
                        numeros[j] = numeros[j + 1];
                        numeros[j + 1] = valor;
                    }
                }
            }
            for (int i = 0; i < numeros.Length; i++)
            {
                Console.WriteLine("Indice {0} - contenido: {1}", i, numeros[i]);
            }

            Console.WriteLine("\nBURBUGEO (DESCENDENTE)\n");

            for (int i = 1; i < numeros.Length; i++)
            {
                for (int j = 0; j < numeros.Length - 1; j++)
                {
                    if (numeros[j] > numeros[j + 1])
                    {
                        int valor = numeros[j];
                        numeros[j] = numeros[j + 1];
                        numeros[j + 1] = valor;
                    }
                }
            }
            for (int i = 0; i < numeros.Length; i++)
            {
                Console.WriteLine("Indice {0} - contenido: {1}", i, numeros[i]);
            }



            Console.ReadKey();
        }
    }
}
