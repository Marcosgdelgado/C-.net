﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa1
{
    class Program
    {
        static void Main(string[] args)
        {
            //if(num%2!=0) saca resto de division
            // si var no esta declarada como double no se podra dividir
            // if(num&1==1) validador de impares (1) o pares(0)
            // en binario numeros impares corresponden a 1 y numeros pares corresponden a 0
            /*0 0
             *1 1
             *0 2
             *1 3
             */
            //double num;
            //num = 1;
            //Console.WriteLine((num % 2 == 0) ? "par" : "impar"); //reemplaza IF / ELSE
            //Console.ReadKey();
            
            //Imprimir los números del 1 al 10 salteando de a 2 uno abajo del otro
            int numero=1;
            int sum = 0;
            int multi = 1;
            string x = "";

            Console.WriteLine("Incrmento");
            while (numero<=10)
            {
                Console.WriteLine(numero++);
                //numero++;
            }

            numero = 1;
            Console.WriteLine("\nIncremento de a 2");
            while (numero<=10)
            {
                Console.WriteLine(numero);
                numero +=2;
            }
            /*Imprimir los números del 1 al 10 sin imprimir números 2,5 y 9 uno abajo del otro
             Requisito: se necesita tener conocimiento del operador AND (&&) y del operador NOT (!=)
            */
            numero = 10;
            Console.WriteLine("\nDesincremento" );
            while (numero>=1)
            {
                if (numero!=2 && numero!=5 && numero!=9) Console.WriteLine(numero);
              
                numero--;
            }
            /*Imprimir los números del 1 al 30 sin imprimir números entre el 10 y el 20 uno abajo del otro
            Requisito: se necesita tener conocimientos del operador OR (||)            */
            numero = 1;
            Console.WriteLine("\nIncremento a 30");
            while (numero<=30 )
            {
                if (numero<=10 || numero>=20)
                {
                    Console.WriteLine(numero);
                }
                numero++;
            }

            numero =1;
            Console.WriteLine("\nSumador");
            while (numero<=10)
            {
                sum = sum + numero; 
                numero++;
            }
            Console.WriteLine("La suma del 1 al 10 es: {0}", sum);

            /*Imprimir la suma de los números pares del 1 al 25
            Requisito: se necesita tener conocimientos del operador RESTO (%)
            */
            numero = 1;
            sum = 0;

            Console.WriteLine("\nSumador2");
            while (numero <= 25)
            {
                
                if(numero%2==0)
                {
                   sum = sum + numero;
                }
                numero++;
            }
            Console.WriteLine("La suma de pares del 1 al 25 es: {0}",sum);

            Console.WriteLine("\nMultiplicacion");
            //Imprimir la multiplicación de los números impares que se encuentran entre -10 y 10
            numero = -10;
            while (numero<=10)
            {
                if (numero%2 !=0)
                {
                    multi = multi * numero;
                   
                }
                numero++;
            }
            Console.WriteLine("La multiplicacion de impares del -10 al 10 es: {0}", multi);

            
            Console.WriteLine("\nFOR con TERNARIO");
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine((i % 2 == 0) ? "@":"@@"); 
            }

            Console.WriteLine("\nFOR creciente");
            for (int i = 0; i < 5; i++)
            {
                x = x + "@";
                Console.WriteLine(x);
            }


            Console.ReadKey();
        }
    }
}
