﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IngresodatosArray
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\nFacturacion\n");

            int[] facturacionPorMes = new int[6];
            string[] nombreMeses = new string[] { "enero","febrero","marzo","abril","mayo","junio"};
            double suma = 0;

            for (int meses = 1; meses <= 6; meses++)
            {
                Console.WriteLine("Ingrese facturacion de {0}",nombreMeses[meses-1]);
                int facturacion = Int32.Parse(Console.ReadLine());
                  facturacionPorMes[meses - 1] = facturacion;
            }

            for (int i = 0; i < facturacionPorMes.Length; i++)
            {
                suma += facturacionPorMes[i];
        
            }

            int minimo = facturacionPorMes[0];
            int maximo = facturacionPorMes[0];
            int postMinimo = 0;
            int postMaximo = 0;

            for (int i = 0; i < facturacionPorMes.Length; i++)
            {
                if (facturacionPorMes[i] > maximo)
                {
                    maximo = facturacionPorMes[i];
                    postMaximo = i;
                }
                if (facturacionPorMes[i] < minimo)
                {
                    minimo = facturacionPorMes[i];
                    postMinimo = i;
                }
            }
            Console.WriteLine("Minimo: {0}\tPosicion Minimo: {1}\t Mes: {2} \nMaximo: {3}\tPosicion Maximo: {4}", 
                minimo,
                postMinimo,
                //nombreMeses,
                maximo, 
                postMaximo);
            Console.WriteLine("Suma total: {0}", suma);
            Console.WriteLine("Promedio: {0}", suma / facturacionPorMes.Length);


            Console.ReadKey();
        }
    }
}
