﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa4
{
    class Program
    {
        static void Main(string[] args)
        {
            int contador = 0;

            //Console.WriteLine("WHILE");
            //while(contador <= 10)
            //{
            //    Console.WriteLine(contador);
            //    contador += 2;

            //}

            //contador = 0;
            //Console.WriteLine("DO WHILE");
            //do
            //{
            //    Console.WriteLine(contador);
            //    contador ++;
            //    //contador += 1 o 2 o 3;  
            //}
            //while (contador <= 10);

            String entrada;
            float nota;
            float sumaAcumulada = 0;
            int cantidadDeNotas = 0;

            //Console.WriteLine("Ingrese nota de alumno o X para salir: ");
            //do
            //{
            //    entrada = Console.ReadLine();
            //    if (entrada == "x") break;
                
            //        nota = float.Parse(entrada);
            //    if (nota >= 0 && nota <= 10)
            //    {
            //        sumaAcumulada += nota;
            //        cantidadDeNotas++;
            //    }
            //    else Console.WriteLine("ERROR! Nota no valida");
                
            //} while (true);

            //Console.WriteLine("La cantidad de notas es {0}", cantidadDeNotas);
            //Console.WriteLine("\nLa suma acumulada de notas es {0}", sumaAcumulada);
            //Console.WriteLine("\nEl promedio es {0}", sumaAcumulada/cantidadDeNotas);

            for(int i = 0; i<10;i++)
            {
                if(i%2 == 0) Console.WriteLine(i); //Imprime numeros pares
            }

            Console.WriteLine("\n--------------< ||FIN DEL PROGRAMA|| >---------------");

            Console.ReadKey();
        }
    }
}
