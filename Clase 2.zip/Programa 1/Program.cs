﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa1
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero = 5;
            float numeroDos = 34.6546465421F; //Colocar F al final para que intifique es es FLOAT
            bool entrar = true;
            Console.WriteLine(args[0]); //agregar opciones desde DEBUG -> Properties-> Debug
            Console.WriteLine(args[1]);

            Console.WriteLine("Hello MUNDO");
            Console.WriteLine("El numero es: {0} y el otro es {1}", numero, numeroDos.ToString("N3")); //"N3" convierte a tres decimales
            if (entrar)
            {
                Console.WriteLine("Bienvenido a LOMAS");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Lo esperamos la proxima");
            }

            Console.WriteLine("FIN DEL PROGRAMA");
            Console.ReadKey();
            

        }
    }
}
