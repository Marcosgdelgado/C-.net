﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa3
{
    class Program
    {
        static void Main(string[] args)
        {

            int numDia = (int)DateTime.Now.DayOfWeek;
            string nombreDia;
            //numDia = 4;
            switch(numDia)
            {
                case 0:
                    nombreDia = "Domingol";
                    break;
                case 1:
                    nombreDia = "Lunes";
                    break;
                case 2:
                    nombreDia = "Martes";
                    break;
                case 3:
                    nombreDia = "Miercoles";
                    break;
                case 4:
                    nombreDia = "Juernes";
                    break;
                case 5:
                    nombreDia = "Viernes";
                    break;
                case 6:
                    nombreDia = "Sabago";
                    break;

                default:
                    nombreDia = "Dia mal ingresado";
                    break;
            }
            Console.WriteLine("Hoy es: {0}",nombreDia);

            Console.ReadKey();
        }
    }
}
