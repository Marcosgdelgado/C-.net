﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa2
{
    class Program
    {
        static void Main(string[] args)
        {
            //int edad = 18;
            int n = 32;
            int n2 = Int32.Parse("32");
            
            Console.WriteLine("INGRESE su edad: ");
            int edad = Int32.Parse(Console.ReadLine());
            //int edad = Int32.Parse(args[0]);

            if (edad >= 18 && edad < 120)
            {
                Console.WriteLine("*********************************");
                Console.WriteLine("Su edad es: "+ edad +"\nusted es mayor de edad");
                Console.WriteLine("*********************************");
                Console.WriteLine("\nPresione ENTER para continuar...");
                Console.ReadKey();

                if(edad >= 30 && edad<=80)
                {
                    Console.WriteLine("*********************************");
                    Console.WriteLine("Su edad es: " + edad + "\nusted es abuelo");
                    Console.WriteLine("*********************************");
                    Console.WriteLine("\nPresione ENTER para continuar...");
                    Console.ReadKey();
                }
                else if (edad >=81 && edad <= 100)
                {
                    Console.WriteLine("*********************************");
                    Console.WriteLine("Su edad es: " + edad + "\nusted esta mas cerca del arpa que del violin");
                    Console.WriteLine("*********************************");
                    Console.WriteLine("\nPresione ENTER para continuar...");
                    Console.ReadKey();
                }     

            }

            else if(edad >= 120)
            {
                Console.WriteLine("\nEDAD NO VALIDA");
            }

            else 
            {
                Console.WriteLine("*********************************");
                Console.WriteLine("Su edad es: " + edad + "\nusted es menor de edad");
                Console.WriteLine("*********************************");
                Console.WriteLine("\nPresione ENTER para continuar...");
                Console.ReadKey();
            }

            Console.WriteLine("\n----------------------------- < FIN DEL PROGRAMA > -----------------------------");
            Console.ReadKey();
        }
    }
}
