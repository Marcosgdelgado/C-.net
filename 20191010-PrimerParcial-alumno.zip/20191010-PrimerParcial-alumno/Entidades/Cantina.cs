﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Entidades
{
    public class Cantina
    {
        private List<Botella> botellas;
        private int espaciostotales;
        private static Cantina singleton;

        private Cantina(int espacios)
        {
            this.botellas = new List<Botella>();
            this.espaciostotales = espacios;


        }

       public List<Botella> Botellas
        {
            get
            {
                return this.botellas;
            }
        }

        public static Cantina GetCantina(int espacios)
        {
            if (singleton is null)
            {
                singleton = new Cantina(espacios);

                return singleton;
            }
            else
            {
                singleton.espaciostotales = espacios;

                return singleton;
            }

        }

        public static bool operator +(Cantina c, Botella b)
        {

            if (c.Botellas.Count() < c.espaciostotales)
            {
                c.Botellas.Add(b);

                return true;
            }
            else
            {
                return false;
            }

        }

    }
}
