﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  
    public abstract class Botella
    {
        protected int capacidadML;
        protected int contenidoML;
        protected string marca;
        
        
        public Botella(string marca, int capacidadML,int contenidoML) 
        {
            if (capacidadML < contenidoML )
            {
                contenidoML = capacidadML;
            }

            this.marca = marca;
            this.capacidadML = capacidadML;
            this.contenidoML = contenidoML;
        }

        public int CapacidadLitros
        {
            get
            {
                return (int)(this.capacidadML/1000);
            }
        }

        public int Contenido
        {
            get
            {
                return (int)(this.contenidoML/1000);
            }
            set
            {
                this.contenidoML = value;
            }
        }

        public float PorcentajeContenido
        {
            
            get
            {

                return (this.Contenido*100) / this.CapacidadLitros; 

            }
        }
       
        protected virtual string GenerarInforme()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Marca es: " + this.marca);
            sb.AppendLine("Contenido en Litros: "+ this.Contenido);
            sb.AppendLine("Capacidad en listros: "+ this.CapacidadLitros);
            sb.AppendLine("Porcentaje contenido: " + this.PorcentajeContenido);

            return sb.ToString();
        }

        public abstract int ServirMedida();
      
        public override string ToString()
        {
            return GenerarInforme();
        }

        public enum Tipo
        {
            Vidrio,
            Plastico
        }


    }
}
