﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Cerveza:Botella
    {
        private const int MEDIDA = 330;
        private Tipo tipo;
        

        public Cerveza(string marca ,int capacidadML, int contenidoML) : this(marca,capacidadML, Tipo.Vidrio, contenidoML)
        {
            
        }

        public Cerveza(string marca, int capacidadML, Tipo tipo, int contenidoML):base(marca, capacidadML, contenidoML)
        {
            this.tipo = tipo;
        }

        public override int ServirMedida()
        {
            
            int medidaOchenta;
            int contenidoOchenta;

            if (MEDIDA <= this.Contenido)
            {
                medidaOchenta = (int)(MEDIDA * 0.8);
                base.Contenido -= medidaOchenta;
                return medidaOchenta;
            }
            else
            {

                contenidoOchenta = (int)(Contenido * 0.8);

                base.Contenido -= contenidoOchenta;

                return contenidoOchenta;
            }
        }

        protected override string GenerarInforme()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.GenerarInforme());
            sb.AppendLine("Medida de cerveza: " + MEDIDA);
            sb.AppendLine("Medida servida cerveza: " + this.ServirMedida());

            return sb.ToString();

        }
        //Operator SIEMPRE ES STATIC
        public static implicit operator Botella.Tipo (Cerveza cerveza)
        {
            return cerveza.tipo;
        }

    }
}
