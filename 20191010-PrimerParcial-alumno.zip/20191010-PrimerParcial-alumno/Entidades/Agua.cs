﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Agua : Botella
    {
        private const int MEDIDA = 400;

        public Agua(string marca, int capacidadML, int contenidoML) :base(marca,capacidadML,contenidoML)
        {

        }

        public override int ServirMedida()
        {

            return ServirMedida(MEDIDA);

        }

        public int ServirMedida (int medida)
        {
            int servido;

            if (medida <= this.Contenido)
            {
                base.Contenido -= medida;
                return medida;
            }
            else
            {

                servido = base.Contenido;

                base.Contenido -= base.Contenido;

                return servido;
            }
            
        }

       protected override string GenerarInforme()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.GenerarInforme());
            sb.AppendLine("Medida de agua: " + MEDIDA);
            sb.AppendLine("Medida servida agua: " + this.ServirMedida());

            return sb.ToString();

        }


    }
}
