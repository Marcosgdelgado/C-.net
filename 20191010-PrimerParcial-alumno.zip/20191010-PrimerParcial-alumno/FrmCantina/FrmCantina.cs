﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ControlCantina;
using Entidades;

namespace FrmCantina
{
    public partial class FrmCantina : Form
    {
        public FrmCantina()
        {
            InitializeComponent();
        }

        private void FrmCantina_Load(object sender, EventArgs e)
        {

            this.barra1.SetCantina = Cantina.GetCantina(10);

            //nudCapadidad.Value = 1000;
            nudCapadidad.Maximum = 5000;
            nudCapadidad.Minimum = 1;

            //nudContenido.Value = 1000;
            nudContenido.Maximum = 5000;
            nudContenido.Minimum = 1;

            cmbBotellaTipo.DataSource = Enum.GetValues(typeof(Botella.Tipo));

        }
    
        private void nudCapadidad_ValueChanged(object sender, EventArgs e)
        {


        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Botella.Tipo tipo;
            Enum.TryParse<Botella.Tipo>(cmbBotellaTipo.SelectedValue.ToString(), out tipo);

            if (rbAgua.Checked)
            {
                this.barra1.AgregarBotella(new Agua(lblMarca.Text, (int)nudCapadidad.Value, (int)nudContenido.Value));  
            }
            else
            {
               this.barra1.AgregarBotella(new Cerveza(txtMarca.Text,(int)nudCapadidad.Value, tipo, (int)nudContenido.Value));
            }

        }
    }   
}
