﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa_7
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            bool resultado;
            a = 5;
            b = 8;

            //igualdad
            resultado = (a == b);

            //Distintos
            resultado = (a != b);

            //Mayor que
            resultado = a > b;

            //Menor que 
            resultado = a < b;

            //Mayor igual que
            resultado = a >= b;

            //Menor igual

            resultado = a <= b;


        }
    }
}
