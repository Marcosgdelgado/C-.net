﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejecicio_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 2 - Asignación compacta");
            Console.WriteLine("");
            Console.WriteLine("A");
            int x = 10;
            int y = 20;
            Console.WriteLine(x);
            Console.WriteLine(y);
            Console.WriteLine("B");
            x += 5;
            y -= 15;
            Console.WriteLine(x);
            Console.WriteLine(y);
            Console.WriteLine("C");
            x++;
            y--;
            Console.WriteLine(x);
            Console.WriteLine(y);
            Console.WriteLine("D");
            x *= 4;
            y *= -3;
            Console.WriteLine(x);
            Console.WriteLine(y);
            Console.WriteLine("E");
            x /= 2;
            y /= 4;
            Console.WriteLine(x);
            Console.WriteLine(y);
            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadLine();
        }
    }
}
