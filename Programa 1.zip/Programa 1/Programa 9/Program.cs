﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa_9
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Si sos mayor de 18, podes sacar el registro, caso contrario, no podes sacar el registro*/
            int edad;
            string edadSTR;
            string respuesta;

            //for(int i = 0; i < 5; i++)
            //{ 
                Console.Write("Ingrese edad: ");
                edadSTR=Console.ReadLine();
                edad = Convert.ToInt16(edadSTR);

                if (edad >= 18)
                {
                    Console.WriteLine("ESTAS OK WACHO");
                }
                else if (edad == 16 || edad == 17)
                {

                Console.Write("TENES PERMISO DE LA GFA ? (SI/NO): ");
                respuesta = Console.ReadLine();
                        if (respuesta == "si")
                        {
                            Console.WriteLine("Cheto");
                        }
                        else
                        { 
                            Console.WriteLine("Al horno");
                        }
                }
                else
                { 
                    Console.WriteLine("Pasa por el mostrador de atras y arreglamos");
                }
            Console.Read();
            //}
        }
    }
}
