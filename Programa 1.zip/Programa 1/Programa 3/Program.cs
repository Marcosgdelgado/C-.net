﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa_3
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Cuando declaro una var es <Palabra reservada> + <NOMBRE VAR>
             * No puede arrancar con numeros.
             * No puede contener caract especiales, excepto el _ (guion bajo)
             * BUENAS PRACTICAS
             * Var primer letra del nombre VAR, en minuscula
             * Nombre de variables declarativos (EJ. CUIT, NOMBRECLIENTE, DNI)
             */
            string nombreDesarrollador = "Marcos Delgado";

            Console.WriteLine("HOLA BIGOTE " + nombreDesarrollador);
            Console.ReadKey();

        }
    }
}
