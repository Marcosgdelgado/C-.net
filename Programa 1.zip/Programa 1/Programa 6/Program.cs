﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa_6
{
    class Program
    {
        static void Main(string[] args)
        {
            //verdadero o falso
            bool tengoVAlorDeVerdad;
            bool soyVerdadero = true;
            bool soyFalso = false;
            // operaciones de logica
            // AND = &&
            tengoVAlorDeVerdad = soyVerdadero && soyFalso;
            Console.WriteLine(tengoVAlorDeVerdad);

            //OR = ||
            tengoVAlorDeVerdad = soyVerdadero || soyFalso;
            Console.WriteLine(tengoVAlorDeVerdad);

            //NOT = !
            tengoVAlorDeVerdad = !soyFalso;
            Console.WriteLine(tengoVAlorDeVerdad);

            Console.ReadKey();
        }

    }
}
