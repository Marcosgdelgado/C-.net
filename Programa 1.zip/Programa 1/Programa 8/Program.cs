﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa_8
{
    class Program
    {
        static void Main(string[] args)
        {
            int edad;
            string edadSTR;

            Console.WriteLine("Ingrese edad: ");
            edadSTR = Console.ReadLine();
            edad = Convert.ToInt16(edadSTR);

            if (edad >= 18)
                {
                Console.WriteLine("En la perovich");

                }
            else
                {
                Console.WriteLine("Manda a un mayor que vaya a comprar");
                }
                 
            Console.Read();  // Diferencia entre READKEY y READ. READKEY finaliza ejecucion con cualquier comando de teclado / READ solo ENTER.
    
        }
    }
}
