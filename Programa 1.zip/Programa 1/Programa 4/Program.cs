﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa_4
{
    class Program
    {
        static void Main(string[] args)
        {
            /*^VAR TIPO NUM */
            int montoCompra = 0;
            //declaracion multiple simil C
            int articuloMonto1, articuloMonto2;
            articuloMonto1 =9;
            articuloMonto2 = 10;
            montoCompra = articuloMonto1 + articuloMonto2;

            Console.WriteLine("El monto total: "+ montoCompra);
            
            Console.ReadKey();

        }
    }
}
