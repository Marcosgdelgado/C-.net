﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa_5
{
    class Program
    {
        static void Main(string[] args)
        {
            int a,b,resultado;
            float division;
            string numero;
            a = 5;
            b = 7;

            Console.WriteLine("Ingrese numero: ");
            numero = Console.ReadLine();

            resultado = a + b;

            Console.WriteLine("SUMA: " + resultado);

            resultado = a - b;

            Console.WriteLine("RESTA: " + resultado);

            
            division = (float)a / (float)b;

            Console.WriteLine("DIV: " + division);

            resultado = a * b;

            Console.WriteLine("MUL: " + resultado);

            resultado = a % b;

            Console.WriteLine("El resultado del resto es: " + resultado);

            Console.ReadKey();



         
          }
    }
}
