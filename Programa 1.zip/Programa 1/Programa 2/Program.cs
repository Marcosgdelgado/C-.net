﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa_2
{
    class Program
    {
        static void Main(string[] args)
        {
            // con \n salto de linea
            // \t TAB 
            Console.Write("Rodi gil\t");
            // WriteLine funcion enter
            Console.WriteLine("Juegeee");
            Console.Write("Juegeee");
            Console.ReadKey();
        }
    }
}
