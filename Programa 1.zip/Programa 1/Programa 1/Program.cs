﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //comentado igual que en c
            //Console me deja manejar la consola
            //White imprime
            Console.Write("Hello world");
            //Read lee
            Console.ReadKey();
            
        }
    }
}
